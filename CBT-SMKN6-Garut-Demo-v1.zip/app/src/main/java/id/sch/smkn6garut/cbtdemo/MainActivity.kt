package id.sch.smkn6garut.cbtdemo

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    private val scanner = registerForActivityResult(ScanContract()) { result ->
        val text = result.contents ?: ""
        web.evaluateJavascript("window.onScan(" + JSONObject.quote(text) + ")", null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.onBack && window.onBack()", null)
            }
        })
    }

    private fun setExamBars(hidden: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        WindowCompat.setDecorFitsSystemWindows(window, !hidden)
        if (hidden) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun scan() {
            runOnUiThread {
                scanner.launch(
                    ScanOptions()
                        .setBeepEnabled(false)
                        .setOrientationLocked(false)
                        .setPrompt("Arahkan kamera ke barcode atau QR")
                )
            }
        }

        // Mode ujian: layar penuh, tanpa screenshot, dan disematkan (screen pinning)
        @JavascriptInterface
        fun lockExam() {
            runOnUiThread {
                window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                setExamBars(true)
                try { startLockTask() } catch (e: Exception) { }
            }
        }

        @JavascriptInterface
        fun unlockExam() {
            runOnUiThread {
                try { stopLockTask() } catch (e: Exception) { }
                window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                setExamBars(false)
            }
        }
    }
}
